package br.edu.ifgoiano.aluno.henrique.aula1;

public class Cachorro {
	String raca;
	
	public void emitirSom(){
		System.out.println("Latiu");
	}
	
	public void correr() {
		System.out.println("Correu");
		
	}

}

