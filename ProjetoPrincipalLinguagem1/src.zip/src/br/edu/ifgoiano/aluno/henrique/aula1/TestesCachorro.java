package br.edu.ifgoiano.aluno.henrique.aula1;

public class TestesCachorro {

	public static void main(String[] args) {
		Cachorro cacho1 = new Cachorro();
		cacho1.raca = "pitibul";
		cacho1.emitirSom();
		cacho1.correr();
		System.out.println(cacho1.raca);

	}

}
